﻿using System;

namespace Asteroids.Models
{
    public class Score
    {
        public String PlayerName { get; set; }
        public int Value { get; set; }
    }
}