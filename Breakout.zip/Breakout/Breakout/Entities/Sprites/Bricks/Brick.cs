﻿using Microsoft.Xna.Framework.Graphics;

namespace Breakout.Entities.Sprites.Bricks
{
    public class Brick : Sprite, ICollidable
    {
        public Brick(Texture2D tex)
            : base(tex)
        {
        }

        public virtual void OnDestroy()
        {
        }

        public void OnCollide(Sprite other)
        {
        }
    }
}